-- AlterTable
ALTER TABLE `orders` ADD COLUMN `finalPrice` DOUBLE NULL;
