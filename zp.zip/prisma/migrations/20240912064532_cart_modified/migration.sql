-- AlterTable
ALTER TABLE `cart` ADD COLUMN `refralDiscountAbsolute` DOUBLE NOT NULL DEFAULT 0;
