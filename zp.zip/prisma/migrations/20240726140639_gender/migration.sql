-- AlterTable
ALTER TABLE `admin` ADD COLUMN `gender` VARCHAR(191) NOT NULL DEFAULT 'not specified';
