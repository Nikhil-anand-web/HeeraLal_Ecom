-- AlterTable
ALTER TABLE `orders` ADD COLUMN `referalCoins` INTEGER NOT NULL DEFAULT 0;
