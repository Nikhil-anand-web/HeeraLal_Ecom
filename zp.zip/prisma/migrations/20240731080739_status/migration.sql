-- AlterTable
ALTER TABLE `category` MODIFY `status` INTEGER NOT NULL DEFAULT 1;
