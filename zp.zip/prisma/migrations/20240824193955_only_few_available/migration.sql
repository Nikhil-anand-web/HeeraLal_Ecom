-- AlterTable
ALTER TABLE `varient` ADD COLUMN `maxQuantityForFewAvailable` INTEGER NOT NULL DEFAULT 10;
