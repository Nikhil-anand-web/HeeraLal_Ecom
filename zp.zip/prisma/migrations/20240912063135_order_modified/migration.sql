-- AlterTable
ALTER TABLE `orders` ADD COLUMN `refralDiscountAbsolute` DOUBLE NOT NULL DEFAULT 0;
