-- AlterTable
ALTER TABLE `permissions` ADD COLUMN `offersAndDiscounts` BOOLEAN NOT NULL DEFAULT false;
