-- AlterTable
ALTER TABLE `admin` ADD COLUMN `email` VARCHAR(191) NULL;
