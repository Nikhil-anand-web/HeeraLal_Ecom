-- AlterTable
ALTER TABLE `refeal` ADD COLUMN `isActivated` BOOLEAN NOT NULL DEFAULT false;
