-- AlterTable
ALTER TABLE `permissions` ADD COLUMN `consumerAndOrderManagement` BOOLEAN NOT NULL DEFAULT false;
