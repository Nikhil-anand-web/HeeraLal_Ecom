-- AlterTable
ALTER TABLE `product` ADD COLUMN `tags` VARCHAR(191) NOT NULL DEFAULT 'general';
