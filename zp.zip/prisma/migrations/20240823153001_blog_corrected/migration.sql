-- AlterTable
ALTER TABLE `blog` MODIFY `content` LONGTEXT NOT NULL;
