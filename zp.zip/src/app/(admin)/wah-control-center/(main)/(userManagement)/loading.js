import Spinner from '@/components/global/Spinner'
import React from 'react'

const Loading = () => {
  return (
    <Spinner/>
  )
}

export default Loading
