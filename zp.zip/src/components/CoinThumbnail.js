import React from 'react';

const CoinThumbnail = ({coins=0}) => {
  return (
    <div style={{color:"green"}}>
     Refral Earning ₹{coins}
      
    </div>
  );
};



export default CoinThumbnail;
