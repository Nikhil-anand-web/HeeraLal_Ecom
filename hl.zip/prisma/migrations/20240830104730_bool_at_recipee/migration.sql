-- AlterTable
ALTER TABLE `recipe` MODIFY `status` BOOLEAN NOT NULL DEFAULT true;
