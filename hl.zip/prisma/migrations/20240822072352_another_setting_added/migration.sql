-- AlterTable
ALTER TABLE `permissions` ADD COLUMN `siteManagement` BOOLEAN NOT NULL DEFAULT false;
