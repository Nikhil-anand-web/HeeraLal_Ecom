/*
  Warnings:

  - You are about to drop the column `price` on the `varient` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE `varient` DROP COLUMN `price`;
