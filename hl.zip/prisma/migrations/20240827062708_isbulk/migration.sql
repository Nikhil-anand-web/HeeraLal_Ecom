-- AlterTable
ALTER TABLE `varient` ADD COLUMN `isBulk` BOOLEAN NOT NULL DEFAULT false;
