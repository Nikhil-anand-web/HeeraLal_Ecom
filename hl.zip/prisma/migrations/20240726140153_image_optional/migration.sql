-- AlterTable
ALTER TABLE `admin` MODIFY `profilePic` JSON NULL;
