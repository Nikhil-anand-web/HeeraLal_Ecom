-- AlterTable
ALTER TABLE `permissions` ADD COLUMN `recipes` BOOLEAN NOT NULL DEFAULT false;
