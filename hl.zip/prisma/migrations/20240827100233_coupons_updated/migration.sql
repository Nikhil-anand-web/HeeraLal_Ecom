-- AlterTable
ALTER TABLE `coupons` ADD COLUMN `status` BOOLEAN NOT NULL DEFAULT true;
