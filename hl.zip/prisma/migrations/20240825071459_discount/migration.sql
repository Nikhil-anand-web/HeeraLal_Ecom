-- AlterTable
ALTER TABLE `varient` ADD COLUMN `discount` DECIMAL(10, 2) NOT NULL DEFAULT 0;
