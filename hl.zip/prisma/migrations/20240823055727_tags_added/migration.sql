-- AlterTable
ALTER TABLE `product` ADD COLUMN `tags` JSON NULL;
