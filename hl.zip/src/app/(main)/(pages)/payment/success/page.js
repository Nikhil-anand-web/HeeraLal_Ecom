export default function page() {
    return <h1>Payment Successful</h1>;
  }
  