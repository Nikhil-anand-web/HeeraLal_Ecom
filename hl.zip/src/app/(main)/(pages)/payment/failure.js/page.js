export default function page() {
    return <h1>Payment Failed</h1>;
  }
  